public class ExceptionEx {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here

        try {

            int x = Integer.parseInt(args[0]);
            int y = Integer.parseInt(args[1]);

            int sum = x + y;
            System.out.println("Summing=" + sum);


            try {
                int div = x / y;
                System.out.println("Division=" + div);
            } catch (ArithmeticException ae) {
                System.out.println("Dont give 0 for second value");
            }


            int sub = x - y;
            System.out.println("Subtraction=" + sub);

        } catch (ArrayIndexOutOfBoundsException aie) {
            System.out.println("Please give two values");
        }
	catch (NumberFormatException ne) {
            System.out.println("only integers");
        }
	finally
	{
System.out.println("compulsory");
	}

	

    }
}
