/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package exceptionhandling;

import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Sandeep
 */
public class SourceClass {

    public static void main(String[] args) {
        ExceptionHandling exHandling = new ExceptionHandling();
        DivisionOperands dOperands = new DivisionOperands();
        Scanner sc = new Scanner(System.in);
        dOperands.setA(sc.nextInt());
        dOperands.setB(sc.nextInt());
        System.out.println(dOperands.toString());
        try {
            exHandling.divide(dOperands);
        } catch (UserDefinedException ex) {
            System.out.println(ex.getMessage());
        }
        System.out.println(dOperands.toString());
        sc.close();
    }
}
