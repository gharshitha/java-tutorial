
package exceptionhandling;

import java.util.Scanner;


public class ExceptionHandling
 {

    private static Scanner sc;

    
    public DivisionOperands divide(DivisionOperands dOperands) throws UserDefinedException 
    {
        
        if (dOperands.getB() == 0)
         {
            throw new UserDefinedException();
        }
        dOperands.setResult(dOperands.getA() / dOperands.getB());

        return dOperands;
    }
}
