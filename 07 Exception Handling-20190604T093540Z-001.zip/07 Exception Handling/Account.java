
import java.util.Scanner;

public class Account {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int amount = 5000;
        Scanner scan = new Scanner(System.in);
        System.out.println("Nter amount to withdraw");
        int withdraw = scan.nextInt();
        try {
            if (withdraw > amount) {
                BalanceException be = new BalanceException("insufffinct amount");
                throw be;
            } else {
                amount = amount - withdraw;
	 System.out.println("Balance="+amount);
            }
        } catch (BalanceException be) {
            System.out.println(be.getMessage());
        }

    }
}

class BalanceException extends Exception {

    public BalanceException(String msg) {
        super(msg);
    }
}
