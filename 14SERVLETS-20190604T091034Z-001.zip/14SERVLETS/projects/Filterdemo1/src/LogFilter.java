import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;

public class LogFilter implements Filter
{
	@Override
	public void destroy() {
		System.out.println("-----------------------------------");
		System.out.println("destroy method is called in "+this.getClass().getName());
		System.out.println("-----------------------------------");
	}

	@Override
	public void doFilter(ServletRequest req, ServletResponse res, FilterChain chain)
			throws IOException, ServletException {
		System.out.println("doFilter methos is called in "+this.getClass().getName());
		PrintWriter out=res.getWriter();
		HttpServletRequest request=(HttpServletRequest)req;
		String ipaddress=request.getRemoteAddr();
		System.out.println("IP "+ipaddress+", Time: "+new Date().toString());
		out.print("LogFilter is invoked before<br>");
		chain.doFilter(req, res);
		out.print("LogFilter is invoked after<br>");
	}

	@Override
	public void init(FilterConfig config) throws ServletException 
	{
		System.out.println("----------------------------");
		System.out.println("init method is called in "+this.getClass().getName());
		System.out.println("----------------------------");
	}
}
