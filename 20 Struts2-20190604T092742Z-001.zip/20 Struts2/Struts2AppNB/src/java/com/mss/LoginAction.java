/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mss;

import com.opensymphony.xwork2.ActionSupport;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Velagaleti Sandeep
 */
public class LoginAction extends ActionSupport {

    private String userName;
    private String password;

    @Override
    public String execute() {
        if (loginAuthAction()) {
            return SUCCESS;
        } else {
            return ERROR;
        }
    }

    public boolean loginAuthAction() {
        DbConnectionProvider dbConnectionProvider = new DbConnectionProvider();
        Connection connection = dbConnectionProvider.getConnection();

        String queryString = "SELECT * FROM registration_table WHERE UserName = '" + userName + "'";

        ResultSet resultSet = dbConnectionProvider.executeQuery(connection, queryString);
        try {
            resultSet.next();
            if (password.equals(resultSet.getString(2))) {
                return true;
            }
        } catch (SQLException ex) {
            Logger.getLogger(LoginAction.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}
