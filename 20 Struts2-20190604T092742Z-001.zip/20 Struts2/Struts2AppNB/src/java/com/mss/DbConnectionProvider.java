/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mss;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author Velagaleti Sandeep
 */
public class DbConnectionProvider {

    static final String Db_Driver = "com.mysql.jdbc.Driver";
    // static final String Db_Driver = "com.ibm.db2.jcc.DB2Driver";
    static final String Db_URL = "jdbc:mysql://localhost:3306/sample?zeroDateTimeBehavior=convertToNull";
    // static final String Db_URL = "jdbc:db2://172.17.0.142:50001/itgdb";
    static final String Db_User = "root";
    static final String Db_Password = "root";

    public Connection getConnection() {
        try {
            Class.forName(Db_Driver);
            System.out.println("Connecting to DB now........");
            return DriverManager.getConnection(Db_URL, Db_User, Db_Password);
        } catch (ClassNotFoundException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return null;
    }

    public ResultSet executeQuery(Connection connection, String queryString) {
        try {
            System.out.println(queryString);
            return connection.createStatement().executeQuery(queryString);
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return null;
    }

    public int executeUpdate(Connection connection, String queryString) {
        try {
            return connection.createStatement().executeUpdate(queryString);
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return 0;
    }
}
