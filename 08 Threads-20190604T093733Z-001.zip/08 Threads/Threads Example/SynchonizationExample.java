/**
 * 
 */
package com.mss;

/**
 * @author Velagaleti Sandeep
 */
class SynchronizedLoop {
	synchronized void printTable(int n) { // method not synchronized
		for (int i = 1; i <= 5; i++) {
			System.out.println(n * i);
			try {
				Thread.sleep(400);
			} catch (Exception e) {
				System.out.println(e);
			}
		}
	}
}

class ThreadX extends Thread {
	SynchronizedLoop t;

	ThreadX(SynchronizedLoop t) {
		this.t = t;
	}

	public void run() {
		t.printTable(2);
	}
}

class ThreadY extends Thread {
	SynchronizedLoop t;

	ThreadY(SynchronizedLoop t) {
		this.t = t;
	}

	public void run() {
		t.printTable(5);
	}
}

public class SynchonizationExample {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SynchronizedLoop loop = new SynchronizedLoop();
		ThreadX tx = new ThreadX(loop);
		ThreadY ty = new ThreadY(loop);

		tx.start();
		ty.start();
	}
}
