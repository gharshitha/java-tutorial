/**
 * 
 */
package com.mss;

/**
 * @author Velagaleti Sandeep
 * 
 */
public class DaemonThread extends Thread {

	public void method() {
		System.out.println(Thread.currentThread().isDaemon());
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		DaemonThread thread1 = new DaemonThread();
		DaemonThread thread2 = new DaemonThread();
		DaemonThread thread3 = new DaemonThread();

		thread1.setDaemon(true);
		thread3.setDaemon(true);

		thread1.start();
		thread2.start();
		thread3.start();
	}

}
