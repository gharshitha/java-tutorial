/**
 * 
 */
package com.mss;

/**
 * @author Velagaleti Sandeep
 * 
 */
public class StartSleepRun extends Thread {

	public void run() {
		for (int i = 0; i < 10; i++) {
			/*
			 * try { Thread.sleep(500); } catch (InterruptedException e) {
			 * System.out.println(e); }
			 */
			System.out.println("\t" + Thread.currentThread().getName());
			System.out.println(i);
		}
	}

	public static void main(String args[]) {
		StartSleepRun example1 = new StartSleepRun();
		StartSleepRun example2 = new StartSleepRun();
		StartSleepRun example3 = new StartSleepRun();
		System.out.println("---------- With Start Method ----------");
		example1.start();
		example2.start();

		System.out.println("---------- With Run Method ----------");
		example1.run();
		example2.run();

		 System.out.println("---------- With Join Method ----------");
		 example1.setName("T1");
		 example2.setName("T2");
		 example3.setName("T3");
		 example1.start();
		 try {
		 example1.join();
		 } catch (InterruptedException e) {
		 // TODO Auto-generated catch block
		 e.printStackTrace();
		 }
		 example2.start();
		 example3.start();
		 try {
		 example3.join();
		 } catch (InterruptedException e) {
		 // TODO Auto-generated catch block
		 e.printStackTrace();
		 }
	}
}
