/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mss;

import com.mss.persistentClasses.CityPojo;
import com.mss.util.HibernateUtil;
import java.util.ArrayList;
import java.util.Scanner;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

/**
 *
 * @author Sandeep
 */
public class DemoClass {
    
    public static void main(String[] args){
        System.out.print("Enter ID : \t");
        Scanner sc = new Scanner(System.in);
        int id = sc.nextInt();
//        
        //Configuration Class
//        Configuration cfg = new Configuration().configure();
//        
//        //Getting Connected with DB
//        SessionFactory sFactory = cfg.buildSessionFactory();
        
        SessionFactory sFactory = HibernateUtil.getSessionFactory();
        
        //Creating thread for Session Factory Class
        Session session = sFactory.openSession();
        
//        CityPojo cPojo = (CityPojo) session.get(CityPojo.class, id);
//        
//        System.out.println(cPojo.toString());
        
        String hql = "FROM CityPojo";
        
        Query q = session.createQuery(hql);
        CityPojo cPojo;
        ArrayList al = (ArrayList) q.list();
        
        for(int i = 0; i<al.size(); i++){
            cPojo = (CityPojo) al.get(i);
//            System.out.println(cPojo.toString());
            System.out.println("Country Code :\t"+cPojo.getCountryCode()+"\tCountry Name :\t"+cPojo.getCountryName());
        }
        
        
        //Closing connections
        session.close();
        sFactory.close();
    }
    
}
