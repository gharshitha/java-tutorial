/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mss.persistentClasses;

/**
 *
 * @author Sandeep
 */
public class CityPojo {
    private int countryId;
    private String countryName;
    private String countryCode;
    private String district;
    private int population;

    public int getCountryId() {
        return countryId;
    }

    public void setCountryId(int countryId) {
        this.countryId = countryId;
    }

    public String getCountryName() {
        return countryName;
    }

    public void setCountryName(String countryName) {
        this.countryName = countryName;
    }

    public String getCountryCode() {
        return countryCode;
    }

    public void setCountryCode(String countryCode) {
        this.countryCode = countryCode;
    }

    public String getDistrict() {
        return district;
    }

    public void setDistrict(String district) {
        this.district = district;
    }

    public int getPopulation() {
        return population;
    }

    public void setPopulation(int population) {
        this.population = population;
    }

    public CityPojo() {
    }

    public CityPojo(int countryId, String countryName, String countryCode, String district, int population) {
        this.countryId = countryId;
        this.countryName = countryName;
        this.countryCode = countryCode;
        this.district = district;
        this.population = population;
    }

    @Override
    public String toString() {
        return "CityPojo{" + "countryId=" + countryId + ", countryName=" + countryName + ", countryCode=" + countryCode + ", district=" + district + ", population=" + population + '}';
    }
    
}
