/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mss.hibernateMapping;

/**
 *
 * @author Radha Madhu
 */
public class BasicInfo {
    
    private int id;
    private String name;
    private String parent;
    private String phNumber;
    
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getParent() {
        return parent;
    }

    public void setParent(String parent) {
        this.parent = parent;
    }

    public String getPhNumber() {
        return phNumber;
    }

    public void setPhNumber(String phNumber) {
        this.phNumber = phNumber;
    }
    
}
