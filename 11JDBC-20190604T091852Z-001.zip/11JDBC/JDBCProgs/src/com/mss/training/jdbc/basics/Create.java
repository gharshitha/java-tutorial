package com.mss.training.jdbc.basics;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author Sivaramayya
 */
import java.sql.*;

public class Create {

    public static void main(String a[]) {
        Connection con = null;
        try {
            String url = "jdbc:oracle:thin:@localhost:1521:XE";
            Class.forName("oracle.jdbc.driver.OracleDriver");//loading Driver
            con = DriverManager.getConnection(url, "system", "siva");//getting connection

            Statement st = con.createStatement();

            st.execute("create table mile(sno number(4),sname varchar2(25),hight number(3,2))");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

//172.17.3.226
  