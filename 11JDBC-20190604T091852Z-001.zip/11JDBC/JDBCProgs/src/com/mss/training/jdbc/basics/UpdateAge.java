package com.mss.training.jdbc.basics;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author SivaRamayya
 */
import java.sql.*;
import java.util.Scanner;

public class UpdateAge {

    public static void main(String a[]) {
        Connection con = null;
        Scanner scan = new Scanner(System.in);
        System.out.print("Nter The student no to update his hight");
        int sn = scan.nextInt();
        System.out.print("Nter new hight");
        float sa = scan.nextFloat();
        try {
            String url = "jdbc:oracle:thin:@localhost:1521:XE";
            Class.forName("oracle.jdbc.driver.OracleDriver");//loading Driver
            con = DriverManager.getConnection(url, "system", "siva");//getting connection

            PreparedStatement st = con.prepareStatement("update mile set hight=? where sno=?");
            st.setFloat(1, sa);
            st.setInt(2,sn);
            int c = st.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
