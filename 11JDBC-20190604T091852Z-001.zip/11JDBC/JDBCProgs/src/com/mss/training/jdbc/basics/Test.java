package com.mss.training.jdbc.basics;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Sivaramayya
 */

import java.sql.*;
public class Test
{
   public static void main(String args[ ])
   {
      try
      {
        Connection con=null;
       
        Class.forName("oracle.jdbc.driver.OracleDriver");//loading Driver
          String url="jdbc:oracle:thin:@localhost:1521:XE";
       con=DriverManager.getConnection(url, "system", "siva");//getting connection
       
       System.out.print("Got Connection");
           }
      catch(Exception ex)
      {
       ex.printStackTrace();
      }
   }
}
