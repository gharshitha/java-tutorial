/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mss.training.jdbc.basics;

import java.sql.Connection;
import java.sql.DriverManager;

/**
 *
 * @author shiva
 */
public class TestDSN {
    public static void main(String [] args) {
    Connection con = null;
    try {
      Class.forName("sun.jdbc.odbc.JdbcOdbcDriver") ;

// Connect with a url string
      con = DriverManager.getConnection("jdbc:odbc:sivadb","system","siva");
      System.out.println("DSN Connection ok.");
      con.close();

    } catch (Exception e) {
      System.err.println("Exception: "+e.getMessage());
    }
  }
}
