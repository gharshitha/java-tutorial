package com.mss.training.jdbc.basics;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author SivaRamayya
 */
import java.sql.*;
import java.util.Scanner;

public class Delete {

    public static void main(String a[]) {
        Connection con = null;
        Scanner scan = new Scanner(System.in);
        System.out.print("Nter The student no to delete");
        int sn = scan.nextInt();
        try {
            String url = "jdbc:oracle:thin:@localhost:1521:XE";
            Class.forName("oracle.jdbc.driver.OracleDriver");//loading type4 driver
            con = DriverManager.getConnection(url, "system", "siva");//getting connection
            PreparedStatement st = con.prepareStatement("delete from mile where sno=?");
            st.setInt(1, sn);
            int c = st.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
