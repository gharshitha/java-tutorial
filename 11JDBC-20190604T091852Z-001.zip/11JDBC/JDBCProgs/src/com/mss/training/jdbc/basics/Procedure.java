package com.mss.training.jdbc.basics;


/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author SivaRamayya
 */
import java.sql.*;
import java.util.Scanner;

public class Procedure {

    public static void main(String a[]) {
        Connection con = null;
        Scanner scan = new Scanner(System.in);
        System.out.print("Nter no name one by one");
        int sn = scan.nextInt();
        String sna = scan.next();
        try {
            String url = "jdbc:oracle:thin:@localhost:1521:XE";
            Class.forName("oracle.jdbc.driver.OracleDriver");//loading Driver
            con = DriverManager.getConnection(url, "system", "siva");//getting connection

            CallableStatement st = con.prepareCall("call myProc(?,?)");
            st.setInt(1, sn);
            st.setString(2, sna);
            st.execute();


        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

/*
create or replace procedure myProc(a number,b varchar2)
is
begin
insert into mile(sno,sname) values(a,b);
end;
/
 */
