package com.mss.training.jdbc.basics;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author SivaRamayya
 */

import java.sql.*;
public class Ins {
public static void main(String a[]) {
        Connection con = null;
          try {
            String url="jdbc:oracle:thin:@localhost:1521:XE";
        Class.forName("oracle.jdbc.driver.OracleDriver");//loading Driver
       con=DriverManager.getConnection(url, "system", "siva");//getting connection
       
            Statement ss=con.createStatement();
            int c=ss.executeUpdate("insert into mile values(12,'gopi',6.1)");

           

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
