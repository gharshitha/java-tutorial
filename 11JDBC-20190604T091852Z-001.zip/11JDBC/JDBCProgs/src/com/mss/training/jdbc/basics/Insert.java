package com.mss.training.jdbc.basics;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Sivaramayya
 */

import java.sql.*;
import java.util.Scanner;
public class Insert {
public static void main(String a[]) {
        Connection con = null;
        Scanner scan=new Scanner(System.in);
        System.out.print("Nter no name hight one by one");
        int sn=scan.nextInt();
        String sna=scan.next();
        float sh=scan.nextFloat();
        try {
              String url="jdbc:oracle:thin:@localhost:1521:XE";
        Class.forName("oracle.jdbc.driver.OracleDriver");//loading Driver
       con=DriverManager.getConnection(url, "system", "siva");//getting connection
           PreparedStatement st = con.prepareStatement("insert into mile values(?,?,?)");
            st.setInt(1, sn);
            st.setString(2, sna);

            st.setFloat(3, sh);
            int c=st.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
