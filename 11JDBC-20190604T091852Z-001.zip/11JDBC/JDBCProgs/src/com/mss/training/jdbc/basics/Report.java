package com.mss.training.jdbc.basics;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author Sivaramayya
 */
import java.sql.*;

public class Report {

    public static void main(String a[]) {
        try {
            String url = "jdbc:oracle:thin:@localhost:1521:XE";
            Class.forName("oracle.jdbc.driver.OracleDriver");//loading Driver
            Connection con = DriverManager.getConnection(url, "system", "siva");//getting connection


            Statement st = con.createStatement();

            ResultSet rs = st.executeQuery("select * from mile");

            ResultSetMetaData rsmd = rs.getMetaData();
            int cols = rsmd.getColumnCount();

            for (int i = 1; i <= cols; i++) {
                System.out.print(rsmd.getColumnName(i) + "\t");
            }
System.out.print("\n");

            while (rs.next()) {
                for (int i = 1; i <= cols; i++) {
                    System.out.print(rs.getString(i) + "\t");
                }
                System.out.print("\n");
            }

            
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
